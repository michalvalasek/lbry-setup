import xmlrpclib

daemon = xmlrpclib.ServerProxy('http://localhost:7080/')

try:
    daemon.stop()
except:
    pass